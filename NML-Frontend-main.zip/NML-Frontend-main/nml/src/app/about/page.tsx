// srs/app/about.tsx
export default function AboutPage() {
  return (
    <div>
      <h1>Communication and Media</h1>
      <p>Find some information.</p>
    </div>
  );
}
